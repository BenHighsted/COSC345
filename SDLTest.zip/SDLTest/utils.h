#pragma once

// Generate a random number from nr_min to nr_max
int randomNumber(int nr_min, int nr_max);

// Generate a random color from 0 to 255
int randomColor();
